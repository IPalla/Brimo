
rm -r *.dvi *.aux *.log *.lot *.toc